---
title: "Oturum / Ajan Devir Kontrolu"
type: checklist
category: checklists
status: active
version: 1.0.0
updated: 2026-10-07
authority: SSOT
scope: "ADR-007 — oturum hiyerarsisi, yetki devri 4 madde, AGENTS §7 devre paketi"
---

# Oturum / Ajan Devir Kontrolu

**Zorunlu Baglantilar:** [checklist index](index.md) · [vault index](../index.md) · [WORKFLOW](../WORKFLOW.md) · [CLAUDE](../CLAUDE.md) · [AGENTS](../AGENTS.md) · [brain](../brain.md) · [TODOS index](../TODOS/index.md)

> **Tek cumlelik sorumluluk:** Devir paketinin 4 maddeyi tasiydigini ve yetki devrinin kurallara uygun oldugunu denetler.

## §0 Ozet (Answer First)

- **Kullanim:** ilgili is yapilmadan once tek tek isaretlenir; **1 madde bossa RED**.
- **Kapatan:** kullanici (G12); bu liste yalniz kanit hazirlar.
- **Sira:** bu liste [WORKFLOW](../WORKFLOW.md) §1 gate sirasinda ilgili kapidan **once** calistirilir; sirasiz calistirma kapiyi beklemez.
- **Cikti:** isaretli liste + §4 kanit kutusu; kanitsiz "gecti" denemez (G5).

### §0.1 Calistirma zamanlamasi

| Alan | Deger |
|---|---|
| Ne zaman | ilgili is baslamadan **once** (on-kontrol) ya da kapi kapanisinda (kanit) |
| Kim hazirlar | isin ureticisi (matristeki ajan — [AGENTS](../AGENTS.md) §2) |
| Kim kapatir | **yalniz kullanici** (G12) |
| Suresi asilirsa | is durur + [log](../log.md) raporu (WORKFLOW §2, 20 dk esigi) |
| Kanit kutusu | §4 — 4 satir, `EKSIK` bos birakilmaz |

## §1 Kabul Kriterleri (6 madde)

- [ ] **1.** Devre paketi **4 madde dolu**: KALAN IS · DOSYA · KANIT · SINIR
- [ ] **2.** Sinsel devir ("bakar mısın?") **yok**
- [ ] **3.** Derinlik <= 2 (alt oturum kendi yetkisini devretmez)
- [ ] **4.** Dosya sahipligi devredilmis (tek yazici kurali)
- [ ] **5.** Kanitsiz devir **yok** (KANIT satiri bos degil)
- [ ] **6.** Escalation seviyesi uygun (0..3; 3 = kullanici)

## §2 Yakalama (komut / tarama)

| # | Komut | Beklenen cikti |
|---|---|---|
| 1 | `devir paketi kontrolu (4 madde)` | hepsi dolu |
| 2 | `Select-String -Path .ai/log.md -Pattern "KALAN|SINIR"` | devir kaydi var |
| 3 | `oturum derinligi` | <= 2 |

## §3 RED Nedenleri

| # | Neden | Sonuc |
|---|---|---|
| 1 | 4 madde eksik | alici geri cevirir -> `bekle` (taslak sayilir) |
| 2 | Kanitsiz devir | G5 -> is iki kez yapilir |
| 3 | Derinlik > 2 | ADR-007 ihlali -> yetki devri gecersiz |

## §4 Kanit Kutusu (WORKFLOW §2)

```text
KANIT   : <komut> -> <sayilar>
DOSYA   : <yazilan dosyalar>
EKSIK   : YOK ya da DOĞRULAMA GEREKLI
SONRAKI : <adim, ~ sure>
```

## §5 Kaynak (turetilme dayanagi)

- [brain](../brain.md) §1.1 **ADR-007 yakalama: `session-handoff-check` + yetki devri 4 madde**
- [AGENTS](AGENTS.md) §7.1 (devre paketi 4 madde) · §7.2 (3 hamle)
- [ROLE](ROLE.md) §5 (devir zinciri)

> **Not:** Icerik vault belgelerinden **turetilmistir** (G9); kaynakta olmayan madde uydurulmaz.

---

## §6 Iliskili Dosyalar

[index](index.md) · [WORKFLOW](../WORKFLOW.md) · [CLAUDE](../CLAUDE.md) · [AGENTS](../AGENTS.md) · [brain](../brain.md) · [PROJECTS](../PROJECTS.md) · [keys](../keys.md) · [glossary](../glossary.md) · [log](../log.md) · [TODOS index](../TODOS/index.md) · [ADR-031](../.decisions/draft/ADR-031-visual-production-provider.md)

### §6.1 Ayni gecisten gecen diger checklist'ler

Sert kapi on kontrolleri (hepsi kapi kapanisindan **once** calisir; birinde RED varsa siradaki kapi acilmaz):

- [gate-004a-vault-kapanis](gate-004a-vault-kapanis.md) — vault olcumu (GATE-004a)
- [gate-003-ui-onay](gate-003-ui-onay.md) — 7 wireframe + kullanici onayi (GATE-003, HARD STOP)
- [gate-004-ilk-commit](gate-004-ilk-commit.md) — cift bacak build + ilk commit (GATE-004)
- [gate-005-test-kapsami](gate-005-test-kapsami.md) — test + NetArchTest (GATE-005)
- [layer-boundary-check](layer-boundary-check.md) — katman siniri 13 soru

**Ortak kural:** bu checklist'teki bir madde digerinde de RED uretiyorsa **once en alttaki kok neden** kapatilir; yuzey duzeltmesi kapiyi acmaz (CLAUDE G5 — kanitsiz gecis yok).
